# Building d3.js for jsroot

    npm install
    npm run build
    rm -rf node_modules package-lock.json
